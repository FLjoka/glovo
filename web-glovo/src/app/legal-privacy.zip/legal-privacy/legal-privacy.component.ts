import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { GeneralService } from '../services/general.service';

@Component({
  selector: 'app-legal-privacy',
  templateUrl: './legal-privacy.component.html',
  styleUrls: ['./legal-privacy.component.sass']
})
export class LegalPrivacyComponent implements OnInit {
  subscribe! : Subscription;
  constructor(public general : GeneralService, private router : Router) { }

  ngOnInit(): void {
 

  }
  ngDestroy(){
    this.subscribe.unsubscribe();
  }
  getHeight(){
    return window.innerHeight + "px"
  }
  get70(){
    var resp = (window.innerHeight * 80) / 100;
    return resp + "px";
  }

}
