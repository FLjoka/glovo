import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-en',
  templateUrl: './en.component.html',
  styleUrls: ['./en.component.sass']
})
export class EnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
